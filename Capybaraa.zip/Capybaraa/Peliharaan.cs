﻿// File: Peliharaan.cs
using System;

namespace CapybaraGame
{
    // 4. INHERITANCE: Ini adalah kelas dasar (base class) yang abstrak.
    public abstract class Peliharaan
    {
        // 3. ENCAPSULATION: Properti ini hanya bisa di-set oleh kelas turunan.
        public string Nama { get; protected set; }

        // 2. CONSTRUCTOR: Untuk kelas dasar.
        public Peliharaan(string nama)
        {
            Nama = nama;
        }

        // 5. POLYMORPHISM (OVERRIDING): Metode virtual yang bisa di-override.
        public virtual void TampilkanAksiUnik()
        {
            Console.WriteLine($"{Nama} melakukan aksi hewan pada umumnya.");
        }
    }
}