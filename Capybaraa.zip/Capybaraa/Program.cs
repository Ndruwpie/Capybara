﻿// File: Program.cs
using System;
using System.Threading;
using CapybaraGame; // PENTING: Untuk mengakses kelas dari file lain

class Program
{
    static void Main(string[] args)
    {
        Console.Title = "Capybara Simulator Sederhana";
        Console.WriteLine("--- Selamat Datang di Capybara Simulator ---");
        Console.Write("Beri nama kapibaramu: ");
        string namaPeliharaan = Console.ReadLine();
        if (string.IsNullOrWhiteSpace(namaPeliharaan)) namaPeliharaan = "Masbro";

        // 1. OBJECT: 'masbro' adalah objek/instance dari kelas Capybara.
        Capybara masbro = new Capybara(namaPeliharaan);
        Console.WriteLine($"\nKamu kini merawat {masbro.Nama}, kapibara paling santuy sedunia!");
        Console.ReadKey();

        while (masbro.ApaMasihHidup())
        {
            Console.Clear();
            masbro.TampilkanStatus();

            Console.WriteLine("\nPilih Aksi:");
            Console.WriteLine("1. Beri makan spesial (Semangka)"); // Demo Overloading
            Console.WriteLine("2. Ajak main");
            Console.WriteLine("3. Lihat aksi uniknya");          // Demo Overriding
            Console.WriteLine("4. Keluar");
            Console.Write("Pilihan: ");
            string pilihan = Console.ReadLine();

            switch (pilihan)
            {
                case "1":
                    masbro.BeriMakan("semangka"); // Memanggil versi overloading
                    break;
                case "2":
                    masbro.AjakMain();
                    break;
                case "3":
                    masbro.TampilkanAksiUnik(); // Memanggil versi override
                    break;
                case "4":
                    goto Selesai; // Keluar dari loop
                default:
                    Console.WriteLine("Pilihan tidak ada.");
                    break;
            }

            masbro.LaluiWaktu();
            Thread.Sleep(2000);
        }

        Console.Clear();
        Console.WriteLine("--- GAME OVER ---");
        Console.WriteLine($"{masbro.Nama} telah pergi mencari petualangan baru...");

    Selesai:
        Console.WriteLine("\nTerima kasih sudah bermain!");
    }
}