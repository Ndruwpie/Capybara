﻿// File: Capybara.cs
using System;

namespace CapybaraGame
{
    // 1. CLASS & 4. INHERITANCE: Kelas Capybara adalah turunan dari Peliharaan.
    public class Capybara : Peliharaan
    {
        // 3. ENCAPSULATION: Nilai hanya bisa diubah dari dalam kelas ini.
        public int Kenyang { get; private set; }
        public int Senang { get; private set; }

        // 6. COMPOSITION: Capybara "memiliki sebuah" objek Mainan.
        public Mainan MainanFavorit { get; private set; }

        // 2. CONSTRUCTOR: Memanggil constructor base class dengan ': base(nama)'.
        public Capybara(string nama) : base(nama)
        {
            Kenyang = 60;
            Senang = 60;
            MainanFavorit = new Mainan("Jeruk Mainan"); // Objek Mainan dibuat di sini
        }

        // 5. POLYMORPHISM (OVERLOADING): Dua metode BeriMakan dengan parameter berbeda.
        public void BeriMakan()
        {
            Console.WriteLine($"{Nama} mamam rumput. Nyam!");
            Kenyang = Math.Min(100, Kenyang + 15);
        }

        public void BeriMakan(string makananSpesial)
        {
            Console.WriteLine($"{Nama} makan {makananSpesial} dengan lahap! WUAH ENAK!");
            Kenyang = Math.Min(100, Kenyang + 25);
        }

        public void AjakMain()
        {
            Console.WriteLine($"{Nama} bermain dengan {MainanFavorit.Jenis} dan berendam. Santuy~");
            Senang = Math.Min(100, Senang + 20);
            Kenyang = Math.Max(0, Kenyang - 10);
        }

        // 5. POLYMORPHISM (OVERRIDING): Implementasi spesifik untuk TampilkanAksiUnik.
        public override void TampilkanAksiUnik()
        {
            Console.WriteLine($"{Nama} duduk diam sambil merenung... sangat santai.");
        }

        public void LaluiWaktu()
        {
            Kenyang = Math.Max(0, Kenyang - 5);
            Senang = Math.Max(0, Senang - 5);
        }

        public void TampilkanStatus()
        {
            Console.WriteLine($"\n--- Status {Nama} --- [ Kenyang: {Kenyang}/100 | Senang: {Senang}/100 ]");
        }

        public bool ApaMasihHidup() => Kenyang > 0 && Senang > 0;
    }
}