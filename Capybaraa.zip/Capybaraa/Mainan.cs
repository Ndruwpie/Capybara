﻿// File: Mainan.cs
namespace CapybaraGame
{
    // 6. COMPOSITION: Kelas ini akan menjadi bagian dari kelas Capybara.
    public class Mainan
    {
        public string Jenis { get; }

        public Mainan(string jenis)
        {
            Jenis = jenis;
        }
    }
}